#pragma once

namespace scai 
{
	class MicroUnitData {
			public:
				enum ActionMode {
					Idle,
					Aggressive,
					Defensive,
					Cooldown,
					Attacking
				};
				MicroUnitData(){ mode = Idle; lastAttackFrame = 0; DPSEfficiency = 0; shotsFired = 0; mode = Aggressive; }
				ActionMode mode;
				int lastAttackFrame;
				int lastCooldownFrame;
				double DPSEfficiency;
				int shotsFired;

				void unitJustAttacked(int wpnCD) {
					if (shotsFired == 0) {
						shotsFired++;
						DPSEfficiency = 1;
					}
					else {
						shotsFired++;
						DPSEfficiency += (wpnCD / (double)(BWAPI::Broodwar->getFrameCount() - lastCooldownFrame));
						DPSEfficiency = DPSEfficiency / (double)2;
						//BWAPI::Broodwar->printf("(%i / (%i - %i)) / %i = %f", wpnCD, BWAPI::Broodwar->getFrameCount(), lastCooldownFrame, shotsFired, DPSEfficiency);
					}
				}
	};
}