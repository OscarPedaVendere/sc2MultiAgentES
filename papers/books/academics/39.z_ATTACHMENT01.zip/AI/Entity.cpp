#include "Entity.h"
#include <time.h>


Entity::Entity(string g,string p,int f) { //Legg til mulighet for � inisialisere med verdi.
	Entity::genotype = g;
	Entity::phenotype = p;
	Entity::fitness = f;
	cout << "Child: " + genotype << endl;
	if(Entity::genotype.length()<1) {
		for(int i=0;i<6;i++) {
			int j = rand() % 2 ;
			if(j==1) {
				Entity::genotype = genotype + "1";
			} else {
				Entity::genotype = genotype + "0";
			}
		}
	}
}

void Entity::evolve() {
	phenotype = genotype;
}