#pragma once
#include "tinyxml2.h"
#include "Entity.h"

#include <iostream>
#include <bitset>
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <fstream>
#include <stdlib.h>
#include <boost/algorithm/string.hpp>
#include <cmath>
#include <limits>

using namespace std;

namespace scai {
	class EA {
		public:
		int population_size;
		int parents_size;
		int elitists_size;
		int no_generations;
		int tournament_size;
		double mutation_chance;
		double crossover_chance;

		vector<vector<int>> weightData;

		EA() {
			srand(time(NULL));
			loadData();
			
			if(elitists_size > 0)
				population_size = population_size - elitists_size;
		}

		void evolve(tinyxml2::XMLDocument* doc) {
			vector <Entity*> entities = getCurrentGeneration(doc);
			vector <Entity*> parents;
			parents = rr_selection(entities);
			entities.clear();
			entities = breeding(parents);

			if(elitists_size > 0) {	
				for(int i=0;i<elitists_size;i++) {
					entities.push_back(parents.at(i));
				}
			}
			int newId = doc->LastChild()->ToElement()->IntAttribute("id") + 1;
			tinyxml2::XMLNode* newGen = doc->InsertAfterChild(doc->LastChild(), doc->NewElement("generation"));
			
			//add new generation to xml-dom
			newGen->ToElement()->SetAttribute("id",newId);
			doc->InsertEndChild(newGen);
			for (int i=0; i < entities.size(); i++) {
				tinyxml2::XMLNode* genome = doc->NewElement("genome");
				genome->ToElement()->SetAttribute("tested","0");
				genome->InsertFirstChild(doc->NewElement("bitstring"));
				genome->FirstChild()->InsertFirstChild(doc->NewText(entities.at(i)->genotype.c_str()));
				genome->InsertAfterChild(genome->LastChild(), doc->NewElement("objective"));
				//genome->LastChild()->ToElement()->SetAttribute("fitness", entities.at(i)->objectives[0]);
				//genome->LastChild()->ToElement()->SetAttribute("min", entities.at(i)->objectives[0]);
				//genome->LastChild()->ToElement()->SetAttribute("value","0");

				if (i==0)
					newGen->InsertFirstChild(genome);
				else
					newGen->InsertAfterChild(newGen->LastChild(),genome);
			}

			parents.clear();
			entities.clear();
		}

		void evolveWithMOO(tinyxml2::XMLDocument* doc) {
			log("get current generation");

			vector <Entity*> children = getCurrentGeneration(doc);
			vector <Entity*> adults;

			log("children:");
			for (int i=0; i<children.size(); i++)
				log(children.at(i)->genotype.c_str());

			if (doc->LastChild()->ToElement()->IntAttribute("id") != 0) {
				log("getting previous generation");
				adults = getPreviousGeneration(doc);
			}
			log("adults:");
			for (int i=0; i<adults.size(); i++)
				log(adults.at(i)->genotype.c_str());

			vector <Entity*> R; //children+adults
			vector <Entity*> P; //new population

			P.reserve(population_size);
			R.reserve( children.size() + adults.size() );
			R.insert(R.end(), children.begin(), children.end());
			R.insert(R.end(), adults.begin(), adults.end());

			vector<vector<Entity*>> F = fastNonDominatedSort(R);

			if (adults.size() != 0) {

				log("AFTER NON DOMINATED SORT:");
				for (int i=0; i<F.size(); i++) {
					log("front ");
					log(int2char(i).c_str());
					for (int n=0; n < F.at(i).size(); n++) {
						log(F.at(i).at(n)->genotype.c_str());
					}
				}
				
				log("moving on to crowding");


				//fill population
				int i = 0;
				while (P.size() < population_size) {
					crowdingDistanceAssignment(F[i]);
					for (int p=0; p < F[i].size(); p++) {
						P.push_back(F[i][p]);
					}
					i++;
				}
/*
				log("AFTER CROWDING ASSIGNMENT:");
				for (int i=0; i<P.size(); i++) {
					log(P.at(i)->genotype.c_str());
					log(P.at(i)->toString().c_str());
				}
*/			
				//sort descending order
				for (int p=0; p < P.size(); p++) {
					for (int q=0; q < P.size(); q++) {
						if (q != p) {
							if (crowdComparison(P[q],P[p])) {
								swap(P[p],P[q]);
							}
						}
					}
				}
/*
				log("AFTER CROWDING ASSIGNMENT SORTING:");
				for (int i=0; i<P.size(); i++) {
					log(P.at(i)->genotype.c_str());
					log(P.at(i)->toString().c_str());
				}
*/
				//cut off until N-population remains
				P.erase(P.begin()+population_size, P.end());
/*				
				log("AFTER CUT:");
				for (int i=0; i<P.size(); i++) {
					log(P.at(i)->genotype.c_str());
					log(P.at(i)->toString().c_str());
				}
*/
			}

			else {
				//if first generation, then sort only by rank
				for (int p=0; p < F.size(); p++) {
					for (int q=0; q < F.at(p).size(); q++) 
						P.push_back(F.at(p).at(q));
				}
			}

			
			vector<Entity*> offspring = breeding(binaryTournamentSelection(P));
			
			//cleanup past generation to get ridd of people who couldnt make it
			tinyxml2::XMLNode* currentGeneration = doc->LastChild();
			currentGeneration->DeleteChildren();
			
			insertEntitiesOnNode(P, currentGeneration, doc);


			//store the offspring to new generation
			int newId = doc->LastChild()->ToElement()->IntAttribute("id") + 1;
			tinyxml2::XMLNode* newGen = doc->InsertAfterChild(doc->LastChild(), doc->NewElement("generation"));
			newGen->ToElement()->SetAttribute("id",newId);
			insertEntitiesOnNode(offspring, newGen, doc);
		}

		//generate a random start-population for the XML
		void startGen(tinyxml2::XMLDocument* doc) {
			tinyxml2::XMLNode* genZero = doc->InsertAfterChild(doc->LastChild(), doc->NewElement("generation"));
			genZero->ToElement()->SetAttribute("id",0);
			for (int i=0; i < population_size; i++) {
				tinyxml2::XMLNode* newUnit = doc->NewElement("genome");
				newUnit->ToElement()->SetAttribute("tested",0);
				newUnit->ToElement()->SetAttribute("inProgress",0);
				newUnit->InsertFirstChild(doc->NewElement("bitstring"));
				newUnit->FirstChild()->InsertFirstChild(doc->NewText(randomChromosome().c_str()));
				newUnit->InsertEndChild(doc->NewElement("fitness"));
				newUnit->LastChild()->ToElement()->SetAttribute("value",0);
				newUnit->InsertEndChild(doc->NewElement("objective"));
				newUnit->InsertEndChild(doc->NewElement("objective"));
				newUnit->InsertEndChild(doc->NewElement("objective"));
				newUnit->InsertEndChild(doc->NewElement("objective"));
				//newUnit->LastChild()->ToElement()->SetAttribute("value",0);
				//newUnit->LastChild()->ToElement()->SetAttribute("inProgress",0);
				genZero->InsertEndChild(newUnit);
			}
		}

		//logic behind genotype->phenotype conversion
		vector <double> getPhenotype(string bitstring) {
			vector<double> w;
			int position = 0;

			for (int i=0; i < weightData.size(); i++) {
				log(int2char(position).c_str());
				log(int2char(weightData.at(i).at(2)).c_str());
				string gene = bitstring.substr(position, weightData.at(i).at(2));
				log(gene.c_str());
				position += (int)weightData.at(i).at(2);
				long l = bitset<numeric_limits<unsigned long>::digits>(gene).to_ulong();
				//normalize
				int bitMax = std::pow((double)2,(double)weightData.at(i).at(2));
				int rangeDiff = weightData.at(i).at(1) - weightData.at(i).at(0);
				double value = rangeDiff * ((double)l/(double)bitMax) + weightData.at(i).at(0);
				w.push_back(value);
			}

			return w;
		}

	private:

		void insertEntitiesOnNode(vector<Entity*> entities, tinyxml2::XMLNode* node, tinyxml2::XMLDocument* doc) {
			for (int i=0; i < entities.size(); i++) {
				tinyxml2::XMLNode* genome = doc->NewElement("genome");
				genome->ToElement()->SetAttribute("tested",entities.at(i)->tested);
				genome->InsertFirstChild(doc->NewElement("bitstring"));
				genome->FirstChild()->InsertFirstChild(doc->NewText(entities.at(i)->genotype.c_str()));
				genome->InsertAfterChild(genome->LastChild(), doc->NewElement("fitness"));
				genome->LastChild()->ToElement()->SetAttribute("value","0");
				for (int o=0; o < sizeof(entities.at(i)->objectives)/sizeof(double); o++) {
					genome->InsertEndChild(doc->NewElement("objective"));
					genome->LastChild()->ToElement()->SetAttribute("fitness",entities.at(i)->objectives[o]);
					genome->LastChild()->ToElement()->SetAttribute("min",entities.at(i)->min[o]);
					genome->LastChild()->ToElement()->SetAttribute("max",entities.at(i)->max[o]);
				}

				if (i==0)
					node->InsertFirstChild(genome);
				else
					node->InsertAfterChild(node->LastChild(),genome);
			}
		}

		vector<Entity*> getCurrentGeneration(tinyxml2::XMLDocument* doc) {
			vector <Entity*> entities;
			
			tinyxml2::XMLNode* currentNode = doc->LastChild()->FirstChild();

			//load population
			while (currentNode != NULL) {
				Entity* e1 = xmlNodeToEntity(currentNode);
				entities.push_back(e1);
				currentNode = currentNode->NextSibling();
			}

			return entities;
		}

		vector<Entity*> getPreviousGeneration(tinyxml2::XMLDocument* doc) {
			vector <Entity*> entities;
			
			tinyxml2::XMLNode* currentNode = doc->LastChild()->PreviousSibling()->FirstChild();

			//load population
			while (currentNode != NULL) {
				Entity* e1 = xmlNodeToEntity(currentNode);
				entities.push_back(e1);
				currentNode = currentNode->NextSibling();
			}

			return entities;
		}

		Entity* xmlNodeToEntity(tinyxml2::XMLNode* node) {
			Entity* e = new Entity(string(node->FirstChildElement("bitstring")->GetText()));
			e->tested = node->ToElement()->IntAttribute("tested");
			//e->fitness = node->LastChildElement("fitness")->IntAttribute("value");
			tinyxml2::XMLElement* obj = node->FirstChildElement("objective");
			for (int o=0; o < sizeof(e->objectives)/sizeof(double); o++) {
				e->objectives[o] = obj->DoubleAttribute("fitness");
				e->min[o] = obj->IntAttribute("min");
				e->max[o] = obj->IntAttribute("max");
				obj = obj->NextSiblingElement("objective");
			}
			return e;
		}

		//produce a random chromosome
		string randomChromosome() {
			int gLength = 0;
			string g;
			for (int i=0; i < weightData.size(); i++) {
				gLength += weightData.at(i).at(2);
			}
			for (int i=0; i<gLength; i++) {
				if (rand() % 2 == 0)
					g.append("0");
				else g.append("1");
			}
			return g;
		}

		vector <Entity*> rr_selection (vector <Entity*> entities) {
			std::sort(entities.begin(), entities.end());

			vector <Entity*> parents;
			for(int i=0;i<parents_size;i++) {
				parents.push_back(entities.at(i));
			}
			
			return parents;
		}

		vector <Entity*> tournament_selection (vector <Entity*> entities) {
			vector <Entity*> parents;
			for(int i=0;i<parents_size;i++) {
				vector <Entity*> participants;
				for(int j=0;j<tournament_size;j++){
					participants.push_back(entities.at(rand() % population_size));
				}
				std::sort(entities.begin(), entities.end());
				parents.push_back(participants.at(0));
				}
				
			return parents;
		}

		vector <Entity *> binaryTournamentSelection(vector <Entity*> pool) {
			vector<Entity*> parents;
			parents.reserve(parents_size);

			for (int i=0; i < parents_size; i++) {
				int rnd = rand() % pool.size();
				Entity* p1 = pool[rnd];
				pool.erase(pool.begin() + rnd);
				rnd = rand() % pool.size();
				Entity* p2 = pool[rnd];
				pool.erase(pool.begin() + rnd);
				log("p1:");
				log(p1->genotype.c_str());
				log("p2:");
				log(p2->genotype.c_str());
				if (crowdComparison(p1,p2)) {
					parents.push_back(p1);
					pool.push_back(p2);
					log("p1 is bigger");
				} 
				else {
					parents.push_back(p2);
					pool.push_back(p1);
					log("p2 is bigger");
				}
			}

			return parents;
		}

		vector <Entity*> breeding (vector <Entity*> parents) {
			vector <Entity*> children;
			log("breeding");
			log("got parents:");
			for (int i=0; i < parents.size(); i++)
				scai::log(parents.at(i)->genotype.c_str());

			//children.reserve(population_size);
			for(int i=0;i< population_size;i=i+2) {
				vector <Entity*> temp;
				int j = i % parents_size;
				if(j == parents_size-1) {
					Entity *e1 = new Entity(parents.at(parents_size-1)->genotype);
					Entity *e2 = new Entity(parents.at(0)->genotype);
					temp = crossover(e1, e2);
				} else {
					Entity *e1 = new Entity(parents.at(j)->genotype);
					Entity *e2 = new Entity(parents.at(j+1)->genotype);
					temp = crossover(e1, e2);
				}

				children.push_back(mutation(temp.at(0)));
 				children.push_back(mutation(temp.at(1)));
			}

			return children;
		}

		Entity* mutation (Entity* parent) {
			log("mutation");
			if((rand() % 100) < (mutation_chance * 100)) {
				int j = rand() % parent->genotype.length();
				if(parent->genotype.at(j) == '1') {
					parent->genotype.replace(j, 1, "0");
				} else {
					parent->genotype.replace(j, 1, "1");
				}
			}
			return parent;
		}

		vector <Entity*> crossover (Entity* parent1, Entity* parent2) {
			log("crossover");
			vector <Entity*> mutated;
			mutated.push_back(parent1);
			mutated.push_back(parent2);

			if((rand() % 100) < (crossover_chance * 100)) {	
				int crossPoint = (rand() % 5) + 1;
				int n = 0;
				for (int i=0; i < crossPoint; i++) {
					n += weightData.at(i).at(2);
				}

				string temp = mutated.at(0)->genotype;
				string temp2 = mutated.at(1)->genotype;
				log(temp.c_str());
				log(temp2.c_str());
				log("becomes");
				log(int2char(n).c_str());
				mutated.at(0)->genotype = temp.substr(0, n) + temp2.substr(n, temp2.size());
				mutated.at(1)->genotype = temp2.substr(0, n) + temp.substr(n, temp.size());	
				log(mutated.at(0)->genotype.c_str());
				log(mutated.at(1)->genotype.c_str());
			}

			return mutated;
		}

		vector<vector<Entity*>> fastNonDominatedSort(vector<Entity*> population) {
			vector<vector<Entity*>> F;
			vector<Entity*> F1;
			//first front is handled differently
			for (int p=0; p < population.size(); p++) {
				for (int q=0; q < population.size(); q++) {
					if (p != q) {
						bool dominated = true;
						bool dominates = true;

						for (int m=0; m < 4; m++) {
							if (population.at(p)->objectives[m] >= population.at(q)->objectives[m])
								dominated = false;
							else if (population.at(p)->objectives[m] < population.at(q)->objectives[m])
								dominates = false;
						}

						if (dominates) {
							//p dominates q, add q to Sp
							population.at(p)->S.push_back(population.at(q));
							log(population.at(p)->genotype.c_str());
							log("dominates");
							log(population.at(q)->genotype.c_str());
						}
						else if (dominated) {
							log(population.at(q)->genotype.c_str());
							log("dominated");
							log(population.at(p)->genotype.c_str());
							population.at(p)->n += 1;
						}
						else if (dominates && dominated) {
							log("WAIT WHAT WHAT WHAT?");
						}
					}
				}
				if (population.at(p)->n == 0) {
					F1.push_back(population.at(p));
					population.at(p)->rank = 0;
				}
			}
			F.push_back(F1);

			//loop through the list of dominated solutions
			while (F[F.size() - 1].size() != 0) {
				vector<Entity*> H;
				int i = F.size() - 1;

				for (int p=0; p < F[i].size(); p++) {
					for (int q=0; q < F[i][p]->S.size(); q++) {
						F[i][p]->S[q]->n -= 1;

						if (F[i][p]->S[q]->n == 0) {
							H.push_back(F[i][p]->S[q]);
							F[i][p]->S[q]->rank = i+1;
							log("setting rank");
						}
					}
				}
				if (H.size() == 0)
					break;
				F.push_back(H);
			}

			return F;
		}

		void crowdingDistanceAssignment(vector<Entity*> front) {
			for (int i=0; i<front.size(); i++) {
				front[i]->crowdDistance = 0;
			}
			for (int m = 0; m < sizeof(front[0]->objectives)/sizeof(double); m++) {
				sortByObjective(front, m);
				
				front[0]->crowdDistance = 40000; //"infinite"
				front[front.size()-1]->crowdDistance = 40000;

				if (front.size() <= 2)
					return;
				for (int i=1; i < front.size() - 1; i++) {
					front[i]->crowdDistance += (front[i+1]->objectives[m]- front[i-1]->objectives[m]) / (front[i+1]->max[m] - front[i-1]->min[m]); //todo: del p� (m-max - m-min)
				}
			}
		}

		//checks if i >= j when taking pareto spreading into account
		bool crowdComparison(Entity* i, Entity* j) {
			return (i->rank < j->rank) || ((i->rank == j->rank) && (i->crowdDistance > j->crowdDistance));
		}

		void sortByObjective(vector<Entity*> &entities, int obj) {
			for (int i=0; i < entities.size(); i++) {
				for (int y=0; y < entities.size(); y++) {
					if (entities[y]->objectives[obj] > entities[i]->objectives[obj]) {
						std::swap(entities[y],entities[i]);
					}
				}
			}
		}

		void loadData() {
			vector<vector<int>> data;
			string line;
			ifstream f ("bwapi-data\\logs\\attributes.txt");

			int c = 0;

			if (f.is_open()) {
				while (f.good()) {
					getline(f,line);
					vector<string> tokens;
					boost::split(tokens, line, boost::is_any_of(" "));
					
					//load 6 ea params 
					switch (c) {
						case 0:
							population_size = atoi(tokens.at(1).c_str());
							break;
						case 1:
							parents_size = atoi(tokens.at(1).c_str());
							break;
						case 2:
							elitists_size = atoi(tokens.at(1).c_str());
							break;
						case 3:
							no_generations = atoi(tokens.at(1).c_str());
							break;
						case 4:
							tournament_size = atoi(tokens.at(1).c_str());
							break;
						case 5:
							mutation_chance = atof(tokens.at(1).c_str());
							break;
						case 6:
							crossover_chance = atof(tokens.at(1).c_str());
							break;
						default:
							//load weight ranges
							vector<int> tokenInts;
							tokenInts.push_back(atoi(tokens.at(0).c_str()));
							tokenInts.push_back(atoi(tokens.at(1).c_str()));
							tokenInts.push_back(atoi(tokens.at(2).c_str()));
							data.push_back(tokenInts);
							break;
					}
					c++;
				}
				f.close();
			}
			weightData = data;
		}

		string int2char(int i) {
			ostringstream os;
			os << i;
			return os.str();
		}
		string double2char(double d) {
			ostringstream os;
			os << d;
			return os.str();
		}
	};
}