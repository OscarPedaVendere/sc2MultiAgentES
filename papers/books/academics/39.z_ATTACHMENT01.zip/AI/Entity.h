#include <string>
#include <limits>
#include <sstream>
using namespace std;

namespace scai {
	struct Entity 
	{
		string genotype;
		string phenotype;
		int fitness;
		double crowdDistance;
		int n; //number of solutions that dominates this entity
		vector<Entity*> S; //set of solutions that this entity dominates
		double objectives[4]; //objective values
		int min[4];
		int max[4];
		int rank; 
		int position; //index position in xml generation
		int tested;

		Entity(string g) : genotype(g) {
			tested = 0;
			n = 0;
			rank = 0;
			for (int i=0; i < sizeof(objectives)/sizeof(double); i++) {
				min[i] = 0;
				max[i] = 0;
				objectives[i] = 0;
			}
		};
		bool operator() (Entity* i, Entity* j) { return i->fitness > j->fitness; }

		string toString() {
			ostringstream os;
			os << "objectives: " << objectives[0] << " " << objectives[1] << " " << objectives[2] << " " << objectives[3] << "\nrank: " << rank << "\ndistance: " << crowdDistance;
			return os.str();
		}
	};
}