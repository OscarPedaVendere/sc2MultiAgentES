#pragma once
#include <BWAPI.h>
#include <boost/algorithm/string.hpp>
//#include <cmath>
#include <math.h>
#include <sstream>
#include "IBehaviour.h"
#include "MyUnitGroup.h"
#include "PotentialFields.h"
#include "MicroUnitData.h"
#include "tinyxml2.h"
#include "log.h"
#include "EA.h"
#include "Objective.h"


namespace scai {

	struct MicroCombat : public IBehaviour {
		std::map<BWAPI::Unit*, MicroUnitData*> unitMap;
		const char* xmlPath;
		int lastFrameChecked;
		int currentGeneration;
		tinyxml2::XMLDocument doc;
		bool evolveOnEnd;
		bool evolutionMaster; //for multiinstance use
		bool doNothing; //used for when an instance needs to wait for new generation
		int doNothingFrameCount;
		int runEachGenom; //times to run each genome
		int genotypeNo;
		int doNothingUntilFrameCount;
		tinyxml2::XMLNode* currentGenome;
		int timeout; //timeout
		EA* ea;
		std::vector<double> weights; //potential field weights

		DPSEfficiency * dpsObjective;
		RemainingHPObjective * hpObjective;
		KeepUnitsAliveObjective* aliveObjective;
		EconomicEfficiencyObjective* economicObjective;

		MicroCombat(const MyUnitGroup &units): IBehaviour(units) {
			for (int i=0; i < units.size(); i++) {
				unitMap.insert(std::make_pair(units.at(i),new MicroUnitData()));
			}
			lastFrameChecked = 0;
			doNothingFrameCount = 0;
			
			evolveOnEnd = false;
			evolutionMaster = true; //set true to compile master-dll
			doNothing = false;
			runEachGenom = 2;
			timeout = 3000;
			xmlPath = "bwapi-data\\logs\\generations.xml";
			ea = new EA();
			BWAPI::Broodwar->enableFlag(BWAPI::Flag::CompleteMapInformation);
			
			doNothingUntilFrameCount = (rand() % 200) + 25;

			dpsObjective = new DPSEfficiency(units.size());
			aliveObjective = new KeepUnitsAliveObjective(units.size());
			economicObjective = new EconomicEfficiencyObjective();
			
			//order units to move to the middle
			int squadHitPoints = 0;
			for (std::map<BWAPI::Unit*, MicroUnitData*>::iterator unit = unitMap.begin(); unit != unitMap.end(); unit++) {
				//unit->first->move(BWAPI::Position(unit->first->getPosition().x() + 1000, unit->first->getPosition().y()));
				squadHitPoints += unit->first->getType().maxHitPoints();
			}
			
			hpObjective = new RemainingHPObjective(squadHitPoints,0);
			BWAPI::Broodwar->setGUI(false);
			BWAPI::Broodwar->setLocalSpeed(0);
		}
		
		virtual void onStart() {
			log("onStart()");
			doNothing = false;
			doc.LoadFile(xmlPath);
			currentGenome = doc.LastChild()->FirstChild();

			if (currentGenome == NULL) {
				//first generation
				if (evolutionMaster) {
					log("generating first generation");
					//ea->startGen(&doc);
					currentGenome = doc.LastChild()->FirstChild();
				}
				else {
					doNothing = true;
					return;
				}
			}
			genotypeNo = 0;
			currentGeneration = doc.LastChild()->ToElement()->IntAttribute("id");

			//find latest genome that hasn't been tested
			while (currentGenome->ToElement()->IntAttribute("tested") >= runEachGenom) {
				genotypeNo++;
				currentGenome = currentGenome->NextSibling();

				if (currentGenome == NULL) {
					//everything has been tested, therefore we must evolve or wait for a new generation
					if (evolutionMaster) {
						log("checking if everyone is finished with their calculations");
						tinyxml2::XMLNode* nodeCheck = doc.LastChild()->FirstChild();
						bool everyoneDone = true;
						/*
						while (nodeCheck != NULL) {
							if (nodeCheck->ToElement()->IntAttribute("inProgress") > 0) 
								everyoneDone = false;
							nodeCheck = nodeCheck->NextSibling();
						}*/
						if (everyoneDone) {
							log("Evolving...");
							//ea->evolve(&doc);
							ea->evolveWithMOO(&doc);
							doc.SaveFile(xmlPath);
							//doNothing = true;
							break;
						}
						else {
							log("everyone is not done yet..");
							doNothing = true;
							break;
						}
					}
					else {
						doNothing = true;
						break;
					}
				}
			}
			if (doNothing)
				return;
			//"reserve" the current genome

			weights = ea->getPhenotype(currentGenome->FirstChildElement("bitstring")->GetText());
			currentGenome->ToElement()->SetAttribute("tested",currentGenome->ToElement()->IntAttribute("tested") + 1);
			currentGenome->ToElement()->SetAttribute("inProgress",currentGenome->LastChildElement("fitness")->IntAttribute("inProgress")+1);
			currentGenome->GetDocument()->SaveFile(xmlPath);
		}

		virtual void onEnd() {
			log("onend");
			if (doNothing)
				return;
			//refresh xml
			//doc.LoadFile(xmlPath);
			//currentGenome = doc.LastChild()->FirstChild();

			//for (int i=0; i<genotypeNo; i++) {
			//	currentGenome = currentGenome->NextSibling();
			//}

			//TODO: CHECK KILLSCORE, LOOKS WEIRD
			//int fitness = fitnessScore();
			for (std::map<BWAPI::Unit*, MicroUnitData*>::iterator unit = unitMap.begin(); unit != unitMap.end(); unit++) {
				dpsObjective->updateBeforeDead(unit->second->DPSEfficiency);
			}
			log("calculating objectives");
			log("unit size:");
			log(int2char(units.getUnits().size()).c_str());
			double obj1 = dpsObjective->calc();
			double obj2 = hpObjective->calc(units.getUnits());
			double obj3 = aliveObjective->calc();
			double obj4 = economicObjective->calc();

			//take avarage if rungenome>1
			if (runEachGenom > 1) {
				tinyxml2::XMLNode* objN = currentGenome->FirstChildElement("objective");
				obj1 = (objN->ToElement()->DoubleAttribute("fitness") + obj1) / (double)currentGenome->ToElement()->IntAttribute("tested");
				objN = objN->NextSiblingElement("objective");
				obj2 = (objN->ToElement()->DoubleAttribute("fitness") + obj2) / (double)currentGenome->ToElement()->IntAttribute("tested");
				objN = objN->NextSiblingElement("objective");
				obj3 = (objN->ToElement()->DoubleAttribute("fitness") + obj3) / (double)currentGenome->ToElement()->IntAttribute("tested");
				objN = objN->NextSiblingElement("objective");
				obj4 = (objN->ToElement()->DoubleAttribute("fitness") + obj4) / (double)currentGenome->ToElement()->IntAttribute("tested");
			}

			log("setting attributes");
			tinyxml2::XMLElement* obj = currentGenome->FirstChildElement("objective");
			obj->SetAttribute("fitness",obj1);
			obj->SetAttribute("min", 0);
			obj->SetAttribute("max", 1);
			obj = obj->NextSiblingElement("objective");
			obj->SetAttribute("fitness",obj2);
			obj->SetAttribute("min", 0);
			obj->SetAttribute("max", 1);
			obj = obj->NextSiblingElement("objective");
			obj->SetAttribute("fitness",obj3);
			obj->SetAttribute("min", 0);
			obj->SetAttribute("max", 1);
			obj = obj->NextSiblingElement("objective");
			obj->SetAttribute("fitness",obj4);
			obj->SetAttribute("min", economicObjective->getMin());
			obj->SetAttribute("max", economicObjective->getMax());

			currentGenome->ToElement()->SetAttribute("inProgress", currentGenome->ToElement()->IntAttribute("inProgress") - 1 );
			currentGenome->GetDocument()->SaveFile(xmlPath);
			BWAPI::Broodwar->restartGame();
		}

		virtual Response onFrame() {
			//stupid hack
			if (BWAPI::Broodwar->getFrameCount() == 1) {
				int enemyHitPoints = 0;
				int enemyEcoVal = 0;
				std::set<BWAPI::Unit*>::iterator enemyIt;
				std::set<BWAPI::Unit*> enem = BWAPI::Broodwar->enemy()->getUnits();
				for (enemyIt = enem.begin(); enemyIt != enem.end(); enemyIt++) {
					enemyHitPoints += (*enemyIt)->getType().maxHitPoints();
				}
				hpObjective->eMaxHp = enemyHitPoints;
			}

			units.remove_dead();
			//onEnd+restart hack
			int n = BWAPI::Broodwar->enemy()->supplyUsed();
			if (n <= 0 && BWAPI::Broodwar->elapsedTime() > 5) {
				onEnd();
				return Response(SUCCESS);
			}
			else if (units.isEmpty()) {
				failure();
				return Response(FAILURE);
			}

			drawStats();

			if (doNothing) {
				if (!BWAPI::Broodwar->isPaused())
					BWAPI::Broodwar->pauseGame();
				if (doNothingFrameCount >= doNothingUntilFrameCount) {
					doNothingFrameCount = 0;
					onStart();
				} else doNothingFrameCount++;
			} else if (BWAPI::Broodwar->isPaused()) {
				log("unpausing game");
				BWAPI::Broodwar->resumeGame();
			}
			if (BWAPI::Broodwar->elapsedTime() > timeout) {
				onEnd();
				return Response(SUCCESS);
			}

			for (std::map<BWAPI::Unit*, MicroUnitData*>::iterator unit = unitMap.begin(); unit != unitMap.end(); unit++) {
				if (unit->first->getHitPoints() <= 0) {
					dpsObjective->updateBeforeDead(unit->second->DPSEfficiency);
					aliveObjective->updateKill();
					unitMap.erase(unit);
				}
			}
		
			doSomething();
			return Response(EXECUTING);
			return Response(SUCCESS);
		}

	private:
		int fitnessScore() {
			int fitness = BWAPI::Broodwar->self()->getKillScore() - BWAPI::Broodwar->enemy()->getKillScore();
			//timeout penalty
			if (BWAPI::Broodwar->elapsedTime() < timeout) {
				for (std::map<BWAPI::Unit*, MicroUnitData*>::iterator unit = unitMap.begin(); unit != unitMap.end(); unit++) {
					fitness += (unit->first->getHitPoints() / unit->first->getType().maxHitPoints()) * 100;
				}
			}
			//calculate avarage
			int prevFitness = currentGenome->LastChildElement("fitness")->ToElement()->IntAttribute("value");
			return (fitness + prevFitness) / currentGenome->ToElement()->IntAttribute("tested");
		}

		void doSomething() {
			//if (BWAPI::Broodwar->getFrameCount() - lastFrameChecked < 10)
			//	return;
			lastFrameChecked = BWAPI::Broodwar->getFrameCount();
			std::set<BWAPI::Unit*> hostiles = BWAPI::Broodwar->enemy()->getUnits();

			//loop squadmembers
			for (std::map<BWAPI::Unit*, MicroUnitData*>::iterator unit = unitMap.begin(); unit != unitMap.end(); unit++) {
				/*check if unit is on cooldown*/
				if (unit->first->isAttackFrame()) {
					unit->second->mode = MicroUnitData::Attacking;
					unit->second->lastAttackFrame = BWAPI::Broodwar->getFrameCount();
				}

				std::set<BWAPI::Unit*>::iterator h;

				//see if unit is on cooldown, add 9 frames as threshold in case of lagframes
				if (BWAPI::Broodwar->getFrameCount() - unit->second->lastAttackFrame + 7 < 
					unit->first->getType().groundWeapon().damageCooldown() && unit->second->lastAttackFrame != 0 && unit->second->lastAttackFrame != BWAPI::Broodwar->getFrameCount()) {

					//COOLDOWN/AVOIDANCE MODE
					BWAPI::Broodwar->drawCircleMap(unit->first->getPosition().x(),unit->first->getPosition().y(),15,BWAPI::Colors::Blue,false);	

					std::vector<scai::PotentialField*> fields;

					if (unit->second->mode != MicroUnitData::Cooldown) {
						//todo: fungere nesten, men cooldown-if'en kj�res kanskje litt for tidlig s� den kan bli over 1.0
						unit->second->unitJustAttacked(unit->first->getType().groundWeapon().damageCooldown());
						unit->second->mode = MicroUnitData::Cooldown;
						unit->second->lastCooldownFrame = BWAPI::Broodwar->getFrameCount();
					}
					
					//escape fields
					for (h = hostiles.begin(); h != hostiles.end(); h++) {
						fields.push_back(new scai::EscapeUnitField(unit->first,unit->second,weights,(*h),5));
					}
					
					std::vector<BWAPI::Position*> positions;
					//center of squad field
					for (std::map<BWAPI::Unit*, MicroUnitData*>::iterator ally = unitMap.begin(); ally != unitMap.end(); ally++) {
						positions.push_back(&ally->first->getPosition());
					}
					fields.push_back(new CenterOfSquad(unit->first,unit->second,weights,positions));

					//calculate final euclidian vector
					double* f = new double[2];
					for (int i=0; i<fields.size(); i++) {
						double* fN = fields.at(i)->getForceVector();
						f[0] += fN[0];
						f[1] += fN[1];
					}

					/*
					if (f[0] != 0)
						f[0] = f[0]/abs(f[0]/(double)fields.size());
					if (f[1] != 0)
						f[1] = f[1]/abs(f[1]/(double)fields.size());*/ //????

					//convert vector into fixed moveposition
					double rangle = tan(f[1]/f[0]);
					f[0] = 30 * (f[0]/abs(f[0]));
					f[1] = (abs(f[0]) * (f[1]/abs(f[1]))) * rangle;

					BWAPI::Position& escapePosition = BWAPI::Position(unit->first->getPosition().x() + f[0], unit->first->getPosition().y() + f[1]);


					unit->first->move(escapePosition);
					drawLine(&unit->first->getPosition(), &escapePosition,BWAPI::Colors::Blue);
				}


				//add a 4 frame buffer since its not necessary to issue new commands every frame
				//...at least I think reaction time don't need to be at the 1frame level (plus if I try to
				//tell the unit to attack the target every frame it will cancel its shooting animation).
				//else if (BWAPI::Broodwar->getFrameCount() - unit->first->getLastCommandFrame() > 4) {
				//dragoon->first->getGroundWeaponCooldown() <= Broodwar->getLatencyFrames() + 1
				else {

					BWAPI::Unit* target = NULL;

					BWAPI::Broodwar->drawCircleMap(unit->first->getPosition().x(),unit->first->getPosition().y(),7,BWAPI::Colors::Red,false);	
					
					//place potential fields at nearby enemies
					double pmax = 0;

					for (h = hostiles.begin(); h != hostiles.end(); h++) {
						MaximumShootingDistance* p = new MaximumShootingDistance(unit->first, (*h), unit->second, weights);
						if (p->calcRelForce() > pmax) {
							target = p->target;
							pmax = p->calcRelForce();
						}
					}
					
					if (target != NULL) {
						BWAPI::Position* uPos = &unit->first->getPosition();
						BWAPI::Position* tPos = &target->getPosition();
						drawLine(uPos,tPos,BWAPI::Colors::Red);
						if (!unit->first->isAttackFrame() && unit->first->getTarget() != target) {
							unit->first->attack(target);
						}
					}
				}
			}
		}

		void drawLine(BWAPI::Position* uPos, BWAPI::Position* tPos, BWAPI::Color color) {
			BWAPI::Broodwar->drawLineMap(uPos->x(),uPos->y(),tPos->x(),tPos->y(), color);
		}

		void drawStats() {
			int y = 0;
			int x = 10;
			if (evolutionMaster) {
				BWAPI::Broodwar->drawTextScreen(x,y,string("master").c_str());
				y += 10;
			}
			BWAPI::Broodwar->drawTextScreen(x,y,int2char(currentGeneration).c_str());
		}

		string int2char(int i) {
			ostringstream os;
			os << i;
			return os.str();
		}
		string double2char(double d) {
			ostringstream os;
			os << d;
			return os.str();
		}
	};
}