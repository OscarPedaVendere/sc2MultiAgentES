Master thesis 2012
Dag �yvind Tornes
Jan Eriksson

Deliverables README
-------------------

These instructions have been tested on a computer running Windows XP SP3. YMMV.
It is recomended to install Starcraft and the agent in a folder containing no spaces,
and with full permissions to read/write.

Contents
--------

1) Installing the agent binaries
2) Compiling agent and tools
3) Running the test


Installing the agent binaries
-----------------------------

The precompiled agent is contained in the file bwapi-data.zip

- After installing Starcraft and BWAPI, extract this file into the bwapi-data\ folder.,
- Extract "caselibrary.zip" in "bwapi-data\caseLib\"
- Select one of the *.ini files and copy it to bwapi.ini.
- Start Chaoslauncher, use BWAPI-Release, and run the game.

Compiling agent and tools
-------------------------

The sources are contained in "source.zip".  The agent is distributed as a
Visual Studio 2008 solution, containing 4 projects.

Dependencies:
- Boost 1.49.0 (www.boost.org)
- BWSAL 0.9.12 (code.google.com/p/bwsal)

Instructions:
- Install and compile Boost
- Set an environment variable "BOOST_BASE" pointing to the root directory where
  you installed boost.
- Install BWSAL
- Set an environment variable "BWSAL_BASE" pointing to the root directory where
  you installed BWSAL
- Set an environment variable "STARCRAFT_LOCATION" pointing to the directory
  containing Starcraft
- Open the AgentArchitecture solution
- Build the solution
- The binaries are copied to the appropriate location in the Starcraft folder

Running the tests
-----------------

Tests are specified in textfiles in the "Starcraft\tests\" folder.  A testfile 
follows an exact format:

 runs: 50  (a number specifying the number of games to play)
 race: Random  (any of the legal values of bwapi.ini:race
 database: bwapi-data\caseLib\medium.clustered.index (the filename of the database to use)
 map: Maps\BroodWar\(2)Astral Balance.scm  (any legal starcraft map)

Tests are then enabled in the "Starcraft\settings.txt" file.

 tests\large.txt  (the test to run, or an empty string to disable testing)
 1  (the framedelay to run, in milliseconds)
 1  (enable (1) / disable (0) the ui)

Results are stored in "Starcraft\results\".  The results may be inspected with the
"TestRunner.exe" tool located in the Starcraft root directory.